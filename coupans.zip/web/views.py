from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'index.html')

def stores(request):
    return render(request, 'stores.html')

def category(request):
    return render(request, 'category.html')

def coupans(request):
    return render(request, 'coupans.html')

def dealCoupans(request):
    return render(request, 'dealCoupans.html')

def blog(request):
    return render(request, 'blog.html')
